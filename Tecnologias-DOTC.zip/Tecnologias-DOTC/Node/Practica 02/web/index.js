const express = require('express');
const app = express();

//app.use(express.static(__dirname + '/public/'));
/*app.get('/:name', (req,res) => {
	console.log(req.params.name);
	res.send('<h3>Hello mundo!! ' + req.params.name + '</h3>');
});*/

app.get('/json', (req,res)=> {
	res.json({'name': 'Cucho'});
});

app.post('/json', (req,res)=> {
	res.json({'name': 'Yelyah'});
});

app.listen('3000', function() {
  console.log('Servidor web escuchando en el puerto 3000');
});

//express con 2 llamadas post... localhost:3000/alumnos y que regrese una lista de alumnos, no importa si nombre y clave o lo que sea.

//Con alumnos/id que solo regrese al alumno
