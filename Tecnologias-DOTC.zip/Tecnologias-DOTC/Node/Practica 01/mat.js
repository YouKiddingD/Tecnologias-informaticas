const math = require('mathjs');
var a = 64;

console.log(math.sqrt(a));
